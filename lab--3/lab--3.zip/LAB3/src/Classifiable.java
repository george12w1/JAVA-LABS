public interface Classifiable {
    public void setRank(String s);

}
