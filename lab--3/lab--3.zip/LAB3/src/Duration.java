public class Duration {
    String timeBetween="";
    Duration(String s1,String s2){
        timeBetween=s1 + " to  " + s2;

    }

}
