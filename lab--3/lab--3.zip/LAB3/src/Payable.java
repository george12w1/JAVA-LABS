public interface Payable {
    public void setPrice(int i);
}
